

var = input("What do you want to put in?")

if var = "Food":
	return("I am hungry too")